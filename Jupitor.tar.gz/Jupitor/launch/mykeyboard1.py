﻿#!/usr/bin/env python
import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

from std_msgs.msg import Float64

import sys, select, termios, tty

msg = """
Reading from the keyboard  and Publishing to Twist!
1 2 3 4 : wheel
5 6 7 8 : joint


t : up (+z)
b : down (-z)

anything else : stop

q/z : increase/decrease max speeds by 10%
w/x : increase/decrease only linear speed by 10%
e/c : increase/decrease only angular speed by 10%
红红火火恍恍惚惚
CTRL-C to quit
"""




moveBindings = {
		'1':1,
		'2':2,
		'3':3,
		'4':4,
		'5':5,
		'6':6,
		'7':7,
		'8':8,

	       }





speedBindings={
		'q':(1.1,1.1),
		'z':(.9,.9),
		'w':(1.1,1),
		'x':(.9,1),
		'e':(1,1.1),
		'c':(1,.9),
	      }

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

speed = .5
turn = 1

def vels(speed,turn):
	return "currently:\tspeed %s\tturn %s " % (speed,turn)

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)
	
	pub_joint1 = rospy.Publisher('joint1_position_controller/command', Float64, queue_size = 1)
	pub_joint2 = rospy.Publisher('joint2_position_controller/command', Float64, queue_size = 1)
	pub_joint3 = rospy.Publisher('joint3_position_controller/command', Float64, queue_size = 1)
	pub_joint4 = rospy.Publisher('joint4_position_controller/command', Float64, queue_size = 1)

	pub_wheel1 = rospy.Publisher('wheel1_position_controller/command', Float64, queue_size = 1)
	pub_wheel2 = rospy.Publisher('wheel2_position_controller/command', Float64, queue_size = 1)
	pub_wheel3 = rospy.Publisher('wheel3_position_controller/command', Float64, queue_size = 1)
	pub_wheel4 = rospy.Publisher('wheel4_position_controller/command', Float64, queue_size = 1)

	rospy.init_node('teleop_twist_keyboard')

	x = 0
	y = 0
	z = 0
	th = 0
	status = 0

	try:
		print msg
		print vels(speed,turn)
		while(1):
			key = getKey()
			wheel1_spend = Float64()
			wheel2_spend = Float64()
			wheel3_spend = Float64()
			wheel4_spend = Float64()
			twist = Float64()			
			twist = 1.0

			if key in moveBindings.keys():
				
				if (key == '1'):
					pub_wheel1.publish(twist * speed)
				elif (key == '2'):
					pub_wheel2.publish(twist * speed)
				elif (key == '3'):
					pub_wheel3.publish(twist * speed)
				elif (key == '4'):
					pub_wheel4.publish(twist * speed)
				elif (key == '5'):
					pub_joint1.publish(twist * turn)
				elif (key == '6'):
					pub_joint2.publish(twist * turn)
				elif (key == '7'):
					pub_joint3.publish(twist * turn)
				elif (key == '8'):
					pub_joint4.publish(twist * turn)



			elif key in speedBindings.keys():
				speed = speed * speedBindings[key][0]
				turn = turn * speedBindings[key][1]

				print vels(speed,turn)
				if (status == 14):
					print msg
				status = (status + 1) % 15
			else:
				x = 0
				y = 0
				z = 0
				th = 0
				if (key == '\x03'):
					break

			
			


			#twist = Float64()
			#twist = 1.448448484848484
			#pub_wheel1.publish(twist)
			
			#a[1].publish(twsit)
			#print "aa"

	except:
		print e

	finally:
		twist = Float64()
		twist = 0
		pub_wheel1.publish(twist)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


